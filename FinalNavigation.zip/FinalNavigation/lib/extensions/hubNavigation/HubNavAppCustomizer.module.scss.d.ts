declare const styles: {};
export default styles;
//# sourceMappingURL=HubNavAppCustomizer.module.scss.d.ts.map