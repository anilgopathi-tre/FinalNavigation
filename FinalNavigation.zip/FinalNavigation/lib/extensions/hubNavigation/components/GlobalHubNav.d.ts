import * as React from 'react';
import type { NavNode } from '../helpers/NavApi';
interface GlobalHubNavProps {
    nodes: NavNode[];
    currentUrl: string;
}
export declare const GlobalHubNavigation: React.FC<GlobalHubNavProps>;
export {};
//# sourceMappingURL=GlobalHubNav.d.ts.map