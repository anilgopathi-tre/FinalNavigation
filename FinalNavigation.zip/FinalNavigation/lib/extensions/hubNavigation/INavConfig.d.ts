/**
 * Configuration interface for Hub Navigation styling
 * This config is loaded from SiteAssets/hub-nav-config.json
 */
export interface INavConfig {
    /** Color for current site link (e.g., "#d32f2f") */
    currentSiteColor: string;
    /** Font weight for current site link (e.g., 700) */
    currentSiteFontWeight: number;
    /** Color for other site links (e.g., "#000000") */
    otherSiteColor: string;
    /** Font weight for other site links (e.g., 400) */
    otherSiteFontWeight: number;
}
/** Default configuration when JSON file is not available */
export declare const DEFAULT_NAV_CONFIG: INavConfig;
//# sourceMappingURL=INavConfig.d.ts.map