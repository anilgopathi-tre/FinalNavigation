import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface IHubNavigationApplicationCustomizerProperties {
    /** Optional: Override config file path (default: SiteAssets/hub-nav-config.json) */
    configPath?: string;
}
/** Application Customizer to highlight current site in hub navigation */
export default class HubNavigationApplicationCustomizer extends BaseApplicationCustomizer<IHubNavigationApplicationCustomizerProperties> {
    private _styleElement;
    private _config;
    private _observer;
    private _throttleTimer;
    onInit(): Promise<void>;
    /**
     * Load navigation config from Site Assets JSON file
     */
    private _loadConfig;
    /**
     * Inject CSS styles for navigation highlighting
     */
    private _injectStyles;
    /**
     * Apply CSS classes to navigation links based on current site
     */
    private _applyHighlighting;
    /**
     * Extract site name from URL (e.g., "mysite" from "/sites/mysite/pages")
     */
    private _extractSiteName;
    /**
     * Observe DOM changes with throttling to handle mega menu
     */
    private _observeDOM;
    protected onDispose(): void;
}
//# sourceMappingURL=HubNavigationApplicationCustomizer.d.ts.map