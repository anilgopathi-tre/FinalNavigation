export interface NavNode {
    Id: number;
    Title: string;
    Url: string;
    IsExternal: boolean;
    Children?: NavNode[];
}
export declare function getTopNav(hubUrl: string, ctx: any): Promise<NavNode[]>;
//# sourceMappingURL=NavApi.d.ts.map