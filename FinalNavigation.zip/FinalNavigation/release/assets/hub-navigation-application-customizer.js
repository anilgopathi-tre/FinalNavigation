define("73e36a43-f43d-468d-95c7-795fb20aea3d_0.0.1", ["@microsoft/sp-core-library","@microsoft/sp-application-base","@microsoft/sp-http"], (__WEBPACK_EXTERNAL_MODULE__676__, __WEBPACK_EXTERNAL_MODULE__841__, __WEBPACK_EXTERNAL_MODULE__909__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 575:
/*!****************************************************!*\
  !*** ./lib/extensions/hubNavigation/INavConfig.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_NAV_CONFIG: () => (/* binding */ DEFAULT_NAV_CONFIG)
/* harmony export */ });
/** Default configuration when JSON file is not available */
var DEFAULT_NAV_CONFIG = {
    currentSiteColor: '#D4A017',
    currentSiteFontWeight: 700,
    otherSiteColor: '#000000',
    otherSiteFontWeight: 400
};


/***/ }),

/***/ 841:
/*!*************************************************!*\
  !*** external "@microsoft/sp-application-base" ***!
  \*************************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__841__;

/***/ }),

/***/ 676:
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__676__;

/***/ }),

/***/ 909:
/*!*************************************!*\
  !*** external "@microsoft/sp-http" ***!
  \*************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__909__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!****************************************************************************!*\
  !*** ./lib/extensions/hubNavigation/HubNavigationApplicationCustomizer.js ***!
  \****************************************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/sp-core-library */ 676);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-application-base */ 841);
/* harmony import */ var _microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-http */ 909);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _INavConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./INavConfig */ 575);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var LOG_SOURCE = 'HubNavigationApplicationCustomizer';
/** Throttle delay for DOM observer (ms) */
var OBSERVER_THROTTLE_MS = 300;
/** CSS selectors for hub navigation links */
var NAV_SELECTORS = [
    '[data-automationid="HubNav"] a',
    '[class*="hubNav"] a',
    '[class*="HubNav"] a',
    '[class*="megaMenu"] a',
    '[class*="MegaMenu"] a',
    '[class*="topNav"] a',
    '[class*="TopNav"] a',
    '[class*="CompositeHeader"] a',
    'nav a[href*="/sites/"]',
    '[role="navigation"] a[href*="/sites/"]'
];
/** Application Customizer to highlight current site in hub navigation */
var HubNavigationApplicationCustomizer = /** @class */ (function (_super) {
    __extends(HubNavigationApplicationCustomizer, _super);
    function HubNavigationApplicationCustomizer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._styleElement = null;
        _this._config = _INavConfig__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_NAV_CONFIG;
        _this._observer = null;
        _this._throttleTimer = null;
        return _this;
    }
    HubNavigationApplicationCustomizer.prototype.onInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var error_1;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.info(LOG_SOURCE, 'Initialized');
                        // Load configuration from Site Assets
                        return [4 /*yield*/, this._loadConfig()];
                    case 1:
                        // Load configuration from Site Assets
                        _a.sent();
                        // Inject CSS styles based on config
                        this._injectStyles();
                        // Apply highlighting
                        this._applyHighlighting();
                        // Re-apply on navigation events
                        this.context.application.navigatedEvent.add(this, function () {
                            try {
                                setTimeout(function () { return _this._applyHighlighting(); }, 500);
                            }
                            catch (error) {
                                _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Navigation event handler failed: ".concat(error)));
                            }
                        });
                        // Watch for DOM changes (mega menu opens) with throttling
                        this._observeDOM();
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Initialization failed: ".concat(error_1)));
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/, Promise.resolve()];
                }
            });
        });
    };
    /**
     * Load navigation config from Site Assets JSON file
     */
    HubNavigationApplicationCustomizer.prototype._loadConfig = function () {
        return __awaiter(this, void 0, void 0, function () {
            var siteUrl, configPath, configUrl, response, json, parseError_1, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 8, , 9]);
                        siteUrl = this.context.pageContext.web.absoluteUrl;
                        configPath = this.properties.configPath || 'SiteAssets/hub-nav-config.json';
                        configUrl = "".concat(siteUrl, "/").concat(configPath);
                        return [4 /*yield*/, this.context.spHttpClient.get(configUrl, _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__.SPHttpClient.configurations.v1)];
                    case 1:
                        response = _a.sent();
                        if (!response.ok) return [3 /*break*/, 6];
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, response.json()];
                    case 3:
                        json = _a.sent();
                        this._config = {
                            currentSiteColor: json.currentSiteColor || _INavConfig__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_NAV_CONFIG.currentSiteColor,
                            currentSiteFontWeight: json.currentSiteFontWeight || _INavConfig__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_NAV_CONFIG.currentSiteFontWeight,
                            otherSiteColor: json.otherSiteColor || _INavConfig__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_NAV_CONFIG.otherSiteColor,
                            otherSiteFontWeight: json.otherSiteFontWeight || _INavConfig__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_NAV_CONFIG.otherSiteFontWeight
                        };
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.info(LOG_SOURCE, 'Config loaded from Site Assets');
                        return [3 /*break*/, 5];
                    case 4:
                        parseError_1 = _a.sent();
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Failed to parse config JSON: ".concat(parseError_1)));
                        return [3 /*break*/, 5];
                    case 5: return [3 /*break*/, 7];
                    case 6:
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Config file not found at ".concat(configUrl, ", using defaults"));
                        _a.label = 7;
                    case 7: return [3 /*break*/, 9];
                    case 8:
                        error_2 = _a.sent();
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Failed to load config: ".concat(error_2)));
                        return [3 /*break*/, 9];
                    case 9: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Inject CSS styles for navigation highlighting
     */
    HubNavigationApplicationCustomizer.prototype._injectStyles = function () {
        try {
            if (this._styleElement) {
                this._styleElement.remove();
            }
            this._styleElement = document.createElement('style');
            this._styleElement.setAttribute('data-hub-nav-customizer', 'true');
            this._styleElement.innerHTML = "\n        .hub-nav-current-site,\n        .hub-nav-current-site span,\n        .hub-nav-current-site button,\n        a.hub-nav-current-site {\n          color: ".concat(this._config.currentSiteColor, " !important;\n          font-weight: ").concat(this._config.currentSiteFontWeight, " !important;\n        }\n        \n        .hub-nav-other-site,\n        .hub-nav-other-site span,\n        .hub-nav-other-site button,\n        a.hub-nav-other-site {\n          color: ").concat(this._config.otherSiteColor, " !important;\n          font-weight: ").concat(this._config.otherSiteFontWeight, " !important;\n        }\n      ");
            document.head.appendChild(this._styleElement);
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Failed to inject styles: ".concat(error)));
        }
    };
    /**
     * Apply CSS classes to navigation links based on current site
     */
    HubNavigationApplicationCustomizer.prototype._applyHighlighting = function () {
        var _this = this;
        try {
            var currentSiteUrl = this.context.pageContext.web.absoluteUrl.replace(/\/$/, '').toLowerCase();
            var currentSiteName_1 = this._extractSiteName(currentSiteUrl);
            if (!currentSiteName_1)
                return;
            var allLinks = document.querySelectorAll(NAV_SELECTORS.join(', '));
            allLinks.forEach(function (link) {
                try {
                    var href = link.getAttribute('href') || '';
                    var linkSiteName = _this._extractSiteName(href.toLowerCase());
                    // Remove existing classes
                    link.classList.remove('hub-nav-current-site', 'hub-nav-other-site');
                    // Apply appropriate class
                    if (linkSiteName && linkSiteName === currentSiteName_1) {
                        link.classList.add('hub-nav-current-site');
                    }
                    else if (href.indexOf('/sites/') > -1) {
                        link.classList.add('hub-nav-other-site');
                    }
                }
                catch (linkError) {
                    _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Failed to process link: ".concat(linkError));
                }
            });
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Failed to apply highlighting: ".concat(error)));
        }
    };
    /**
     * Extract site name from URL (e.g., "mysite" from "/sites/mysite/pages")
     */
    HubNavigationApplicationCustomizer.prototype._extractSiteName = function (url) {
        try {
            var match = url.split('/sites/')[1];
            return match ? match.split('/')[0] : '';
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Failed to extract site name from URL: ".concat(error));
            return '';
        }
    };
    /**
     * Observe DOM changes with throttling to handle mega menu
     */
    HubNavigationApplicationCustomizer.prototype._observeDOM = function () {
        var _this = this;
        try {
            if (this._observer)
                return;
            this._observer = new MutationObserver(function () {
                try {
                    // Throttle to prevent excessive calls
                    if (_this._throttleTimer)
                        return;
                    _this._throttleTimer = window.setTimeout(function () {
                        try {
                            _this._applyHighlighting();
                        }
                        catch (error) {
                            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Observer callback failed: ".concat(error)));
                        }
                        finally {
                            _this._throttleTimer = null;
                        }
                    }, OBSERVER_THROTTLE_MS);
                }
                catch (error) {
                    _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Observer throttle failed: ".concat(error)));
                }
            });
            this._observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.error(LOG_SOURCE, new Error("Failed to setup DOM observer: ".concat(error)));
        }
    };
    HubNavigationApplicationCustomizer.prototype.onDispose = function () {
        try {
            if (this._observer) {
                this._observer.disconnect();
                this._observer = null;
            }
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Failed to disconnect observer: ".concat(error));
        }
        try {
            if (this._styleElement) {
                this._styleElement.remove();
                this._styleElement = null;
            }
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Failed to remove style element: ".concat(error));
        }
        try {
            if (this._throttleTimer) {
                clearTimeout(this._throttleTimer);
                this._throttleTimer = null;
            }
        }
        catch (error) {
            _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__.Log.warn(LOG_SOURCE, "Failed to clear throttle timer: ".concat(error));
        }
    };
    return HubNavigationApplicationCustomizer;
}(_microsoft_sp_application_base__WEBPACK_IMPORTED_MODULE_1__.BaseApplicationCustomizer));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HubNavigationApplicationCustomizer);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});;
//# sourceMappingURL=hub-navigation-application-customizer.js.map