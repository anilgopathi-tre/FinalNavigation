declare interface IHubNavigationApplicationCustomizerStrings {
  Title: string;
}

declare module 'HubNavigationApplicationCustomizerStrings' {
  const strings: IHubNavigationApplicationCustomizerStrings;
  export = strings;
}
