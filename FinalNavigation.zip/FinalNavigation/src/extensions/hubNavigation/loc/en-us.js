define([], function() {
  return {
    "Title": "HubNavigationApplicationCustomizer"
  }
});